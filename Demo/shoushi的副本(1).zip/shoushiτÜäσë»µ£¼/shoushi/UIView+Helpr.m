//
//  UIView+Helpr.m
//  shoushi
//
//  Created by Apple on 17/4/10.
//  Copyright © 2017年 shoushi. All rights reserved.
//

#import "UIView+Helpr.h"


@interface UIView ()
//  点击手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, taprecognizertap);
//  滑动手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, swiperecognizertap);
//  长按手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, longrecognizertap);
//  平移手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, panrecognizertap);
//  捏合手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, pinchperecognizertap);
//  旋转手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, rotationrecognizertap);
//  边缘手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, screenEdgePanrecognizertap);
//  双击手势
XH_ATTRIBUTE_COPY_BLOCK(UIRecognizertap, doubleTaprecognizertap);


@end

@implementation UIView (Helpr)

    



-(void)addtapGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return ;
    if (!self.taprecognizertap) {
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self  action:@selector(tapAction:)];
        tap.numberOfTapsRequired =1;
        tap.numberOfTouchesRequired =1;
        tap.delegate = self ;
        [self addGestureRecognizer:tap];
        NSArray * arr = [self gestureRecognizers];
        for (UIGestureRecognizer * ges in arr) {
            if ([ges isKindOfClass:[UITapGestureRecognizer class]] ){
                UITapGestureRecognizer * ges1 = (UITapGestureRecognizer *)ges;
                if (ges1.numberOfTapsRequired == 2) {
                     [tap  requireGestureRecognizerToFail:ges];
                }
            }
        }
    }
    self.taprecognizertap = recognizertap;
    
}

-(void)tapAction:(UITapGestureRecognizer *)tap
{
    if (self.taprecognizertap) {
        self.taprecognizertap(self,tap);
    }
}
#pragma mark----这里是添加滑动手势
-(void)addswipeGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return ;
    if (!self.swiperecognizertap) {
        UISwipeGestureRecognizer *swipe =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
        swipe.direction =UISwipeGestureRecognizerDirectionLeft;
        [self addGestureRecognizer:swipe];
        UISwipeGestureRecognizer *swipe2 =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
        swipe2.direction =UISwipeGestureRecognizerDirectionRight;
        [self addGestureRecognizer:swipe2];
        UISwipeGestureRecognizer *swipe3 =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
        swipe3.direction =UISwipeGestureRecognizerDirectionUp;
        [self addGestureRecognizer:swipe3];
        UISwipeGestureRecognizer *swipe4 =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
        swipe4.direction =UISwipeGestureRecognizerDirectionDown;
        [self addGestureRecognizer:swipe4];
    }
    self.swiperecognizertap = recognizertap;
}

-(void)swipeAction:(UISwipeGestureRecognizer *)swipe
{
    if (self.swiperecognizertap) {
        self.swiperecognizertap(self,swipe);
    }
}
#pragma mark----添加长按手势
-(void)addlongPressGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return;
    if (!self.longrecognizertap) {
        UILongPressGestureRecognizer *longPress =[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAction:)];
        //最短长按时间
        longPress.minimumPressDuration =2;
        //允许移动最大距离
        longPress.allowableMovement =1;
        //添加到指定视图
        [self addGestureRecognizer:longPress];
       
        
    }
   self.longrecognizertap = recognizertap ;
}

-(void)longPressAction:(UILongPressGestureRecognizer *)longPress
{
    if (self.longrecognizertap) {
        
        //判断手势状态
        if (longPress.state == UIGestureRecognizerStateBegan) {
           self.longrecognizertap(self,longPress);  
        }       
    }
}

#pragma mark----添加平移
-(void)addpanGestureTecognizer:(nullable UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return;
    if (!self.panrecognizertap) {
        UIPanGestureRecognizer *pan =[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
        //添加到指定视图
        [self addGestureRecognizer:pan];
    }
    self.panrecognizertap  = recognizertap;
}

-(void)panAction:(UIPanGestureRecognizer *)pan
{
    if (self.panrecognizertap) {
        self.panrecognizertap(self,pan);
    }else {
        //获取手势的位置
        CGPoint position =[pan translationInView:self];
        //通过stransform 进行平移交换
        self.transform = CGAffineTransformTranslate(self.transform, position.x, position.y);
        //将增量置为零
        [pan setTranslation:CGPointZero inView:self];
    }
}

#pragma mark----捏合手势
-(void)addpinchGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return;
    if (!self.pinchperecognizertap) {
        UIPinchGestureRecognizer *pinch =[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchAction:)];
        //添加到指定视图
        [self addGestureRecognizer:pinch];
    }
}
-(void)pinchAction:(UIPinchGestureRecognizer *)pinch
{
    if (self.pinchperecognizertap) {
        self.pinchperecognizertap(self,pinch);
    }else {
        self.transform =CGAffineTransformScale(self.transform, pinch.scale, pinch.scale);
        pinch.scale = 1;
    }
}

#pragma mark----旋转手势
-(void)addrotationGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return;
    if (!self.rotationrecognizertap)
    {
        UIRotationGestureRecognizer *rotation =[[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotationAction:)];
        //添加到指定的视图
        [self   addGestureRecognizer:rotation];
    }
    self.rotationrecognizertap  = recognizertap;
}
-(void)rotationAction:(UIRotationGestureRecognizer *)rote
{
    if (self.rotationrecognizertap) {
        self.rotationrecognizertap(self,rote);
    }else {
        //通过transform 进行旋转变换
        self.transform = CGAffineTransformRotate(self.transform, rote.rotation);
        //将旋转角度 置为 0
        rote.rotation = 0;
    }
}
#pragma mark----边缘手势
-(void)addscreenEdgePanGestureRecognizer:(UIRecognizertap)recognizertap
{
    if (![self addGestureWithView]) return;
    if (!self.screenEdgePanrecognizertap) {
        UIScreenEdgePanGestureRecognizer *screenPan = [[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(screenPanAction:)];
        [self addGestureRecognizer:screenPan];
    }
    self.screenEdgePanrecognizertap = recognizertap;
}

-(void)screenPanAction:(UIScreenEdgePanGestureRecognizer *)screenPan
{
    if (self.screenEdgePanrecognizertap) {
        self.screenEdgePanrecognizertap(self,screenPan);
    }
}


#pragma mark----双击手势
-(void)adddoubleTapGestureRecognizer:(UIRecognizertap)recognizertap{
    if (![self addGestureWithView]) return;
    if (!self.doubleTaprecognizertap) {
        UITapGestureRecognizer * doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:
            self action:@selector(doubleTapAction:)];
        doubleTap.numberOfTapsRequired = 2;
        NSArray * arr = [self gestureRecognizers];
        //拿到tap手势
        for (UIGestureRecognizer * ges in arr) {
            UITapGestureRecognizer * ges1 = (UITapGestureRecognizer *)ges;
            if (ges1.numberOfTapsRequired == 1) {
                [ges1  requireGestureRecognizerToFail:doubleTap];
            }
        }
        


        [self addGestureRecognizer:doubleTap];
    }
    self.doubleTaprecognizertap  = recognizertap;

}

- (void)doubleTapAction:(UITapGestureRecognizer *)tap{
    
    if (self.doubleTaprecognizertap) {
        self.doubleTaprecognizertap(self, tap);
    }
}
//处理uibutton 不给手势处理
-(BOOL)addGestureWithView
{
    if ([self class]== [UIButton class]) {
        return  NO;
    }
    self.userInteractionEnabled = YES ;
    return YES ;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    for (UIView * view in self.subviews) {
        if (![MYRuntime Myclass_isMetaClass:[view class]])
        {
            if ([touch.view isDescendantOfView:view])
            {
                return NO;
            }
        }
    }
    return YES;
}
//点击手势
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, taprecognizertap, Taprecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, swiperecognizertap, Swiperecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, longrecognizertap, Longrecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, panrecognizertap, Panrecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, pinchperecognizertap, Pinchperecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, rotationrecognizertap, Rotationrecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, screenEdgePanrecognizertap, ScreenEdgePanrecognizertap)
XM_SEL_BLOCK(OBJC_ASSOCIATION_COPY_NONATOMIC, UIRecognizertap, doubleTaprecognizertap, DoubleTaprecognizertap)



@end
