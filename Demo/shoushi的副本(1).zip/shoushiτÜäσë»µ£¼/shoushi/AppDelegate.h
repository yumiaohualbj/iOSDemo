//
//  AppDelegate.h
//  shoushi
//
//  Created by Apple on 17/4/10.
//  Copyright © 2017年 shoushi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

