//
//  UIView+Helpr.h
//  shoushi
//
//  Created by Apple on 17/4/10.
//  Copyright © 2017年 shoushi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYRuntime.h"

/*
 *  给系统类添加一个 block 属性
 *  这是申明属性的
 */
#define XH_ATTRIBUTE_COPY_BLOCK(TYPE,NAME) @property(nonatomic,copy)TYPE  NAME
/*
 *  给系统类添加一个 block 属性
 *  这是属性的实现方法
 */
#define XM_SEL_BLOCK(OBJC_ENUM_STR,TYPE,NAME,BIGNAME) \
-(TYPE )NAME\
{\
return objc_getAssociatedObject(self, @#NAME);\
}\
-(void)set##BIGNAME:(TYPE )NAME{\
objc_setAssociatedObject(self, @#NAME, NAME, OBJC_ENUM_STR);\
}


NS_ASSUME_NONNULL_BEGIN

typedef void (^UIRecognizertap)(UIView * view ,UIGestureRecognizer * tap);

@interface UIView (Helpr)<UIGestureRecognizerDelegate>

/**
 *  添加单击手势
 */
-(void)addtapGestureRecognizer:(UIRecognizertap)recognizertap;
/**
 *  添加滑动手势
 */
-(void)addswipeGestureRecognizer:(UIRecognizertap)recognizertap;
/**
 *  添加长按手势
 */
-(void)addlongPressGestureRecognizer:(UIRecognizertap)recognizertap;
/**
 *  添加平移手势
 */
-(void)addpanGestureTecognizer:(nullable UIRecognizertap)recognizertap;
/**
 *  添加捏合手势
 */
-(void)addpinchGestureRecognizer:(nullable UIRecognizertap)recognizertap;
/**
 *  添加旋转手势
 */
-(void)addrotationGestureRecognizer:(nullable UIRecognizertap)recognizertap;
/**
 *  添加边缘手势
 */
-(void)addscreenEdgePanGestureRecognizer:(UIRecognizertap)recognizertap;
/**
 *  添加双击手势
 */
-(void)adddoubleTapGestureRecognizer:(UIRecognizertap)recognizertap;

@end
NS_ASSUME_NONNULL_END
