//
//  masnoryDemoCell.m
//  masonry使用demo
//
//  Created by mac on 16/9/2.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "masnoryDemoCell.h"
#import "WUCSingleSelectView.h"
#import "Masonry/Masonry.h"
@interface masnoryDemoCell ()
@property (nonatomic,strong)UILabel *questionLabel;
@property (nonatomic,strong)WUCSingleSelectView * singleView1;
@property (nonatomic,strong)WUCSingleSelectView * singleView2;
@property (nonatomic,strong)WUCSingleSelectView * singleView3;
@property (nonatomic,strong)WUCSingleSelectView * singleView4;

@end
@implementation masnoryDemoCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createSubViews];
    }
    
    return self;
}


- (void)createSubViews{
    
    
    _questionLabel = [UILabel new];
    _singleView1 = [WUCSingleSelectView new];
    _singleView2 = [WUCSingleSelectView new];
    _singleView3 = [WUCSingleSelectView new];
    _singleView4 = [WUCSingleSelectView new];
    
    [self.contentView addSubview:_questionLabel];
    [self.contentView addSubview:_singleView1];
    [self.contentView addSubview:_singleView2];
    [self.contentView addSubview:_singleView3];
    [self.contentView addSubview:_singleView4];
    
    
    [_questionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(15);
        make.left.equalTo(self.contentView.mas_left).offset(14);
        make.right.equalTo(self.contentView.mas_right).offset(-14);;
        make.bottom.equalTo(_singleView1.mas_top).offset(-15);
        
    }];
    
    [_singleView1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_questionLabel.mas_bottom).offset(15);
        make.left.equalTo(self.contentView.mas_left).offset(14);
        make.right.equalTo(self.contentView.mas_right).offset(-14);;
        make.bottom.equalTo(_singleView2.mas_top).offset(-10);
    }];
    
    [_singleView2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_singleView1.mas_bottom).offset(10);
        make.left.equalTo(self.contentView.mas_left).offset(14);
        make.right.equalTo(self.contentView.mas_right).offset(-14);
        make.bottom.equalTo(_singleView3.mas_top).offset(-10);
    }];
    
    [_singleView3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_singleView2.mas_bottom).offset(10);
        make.left.equalTo(self.contentView.mas_left).offset(14);
        make.right.equalTo(self.contentView.mas_right).offset(-14);
        make.bottom.equalTo(_singleView4.mas_top).offset(-10);
    }];
    
    [_singleView4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_singleView3.mas_bottom).offset(10);
        make.left.equalTo(self.contentView.mas_left).offset(14);
        make.right.equalTo(self.contentView.mas_right).offset(-14);
        make.bottom.equalTo(self.contentView.mas_top).offset(-10);
    }];


}

- (void)setModel:(cellModel *)model{
    
    _model = model;
    
    _questionLabel.text = model.desStr;
    NSArray * options = model.options;
    [_singleView1 setLeftString:@"A" withRightString:options[0] withIsSelected:NO];
    [_singleView1 setLeftString:@"B" withRightString:options[1] withIsSelected:NO];
    [_singleView1 setLeftString:@"C" withRightString:options[2] withIsSelected:NO];
    [_singleView1 setLeftString:@"D" withRightString:options[3] withIsSelected:NO];

}


//- (CGFloat)cellHeighWithModel:(cellModel *)model{
//    
//    CGFloat cellHeight = 0;
//    
//    CGSize labelSize = [_questionLabel sizeThatFits:[self sizeToFit]];
//    
//}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
