//
//  cellModel.h
//  masonry使用demo
//
//  Created by mac on 16/9/2.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface cellModel : NSObject
@property (nonatomic,copy)NSString * desStr;
@property (nonatomic,strong)id  options;
@end
