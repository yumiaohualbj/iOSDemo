//
//  WUCSingleSelectView.h
//  WorlducProject
//
//  Created by mac on 16/8/19.
//  Copyright © 2016年 worlduc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WUCSingleSelectView : UIView
@property(nonatomic,strong)UILabel * leftLabel;
@property(nonatomic,strong)UILabel * rightLabel;
@property(nonatomic,strong)NSString * leftString;
@property(nonatomic,strong)NSString * rightString;
@property(nonatomic,assign)BOOL isSelected;

- (void)setLeftString:(NSString *)leftString withRightString:(NSString *)rightString withIsSelected:(BOOL)isSelected;
//+(CGFloat)getViewHeight:(NSString * )rightlabelText;
@end
