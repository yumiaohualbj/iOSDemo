//
//  WUCSingleSelectView.m
//  WorlducProject
//
//  Created by mac on 16/8/19.
//  Copyright © 2016年 worlduc. All rights reserved.
//

#import "WUCSingleSelectView.h"
#import "Masonry.h"
//颜色
#define MCColor(r, g, b ,alp) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:alp]
@implementation WUCSingleSelectView
- (id)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self createSubViews];
    }
    return self;
}


- (void)createSubViews{
    
   // _leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 25, self.frame.size.height)];
    //  _rightLabel = [[UILabel alloc]initWithFrame:CGRectMake(_leftLabel.right + 15,0 , self.frame.size.width - _leftLabel.width - 15, self.frame.size.height)];

    _leftLabel = [UILabel new];
    _rightLabel = [UILabel new];
    
    [self addSubview:_leftLabel];
    [self addSubview:_rightLabel];
    
    _leftLabel.textAlignment = NSTextAlignmentCenter;
    _leftLabel.font = [UIFont systemFontOfSize:16];

    _rightLabel.textAlignment = NSTextAlignmentLeft;
    _rightLabel.textColor = MCColor(90, 90, 90, 1);
    _rightLabel.font = [UIFont systemFontOfSize:16];
   
    self.layer.borderColor =MCColor(243, 243, 243, 1).CGColor;
    self.layer.borderWidth = .5;
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = 5;
    
    
    [_leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.width.equalTo(@25);
        make.height.equalTo(self.mas_height);
    }];
    [_rightLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(_leftLabel.mas_right).offset(15);
        make.right.equalTo(self.mas_right);
        make.height.equalTo(self.mas_height);
    }];

   
}
- (void)setLeftString:(NSString *)leftString withRightString:(NSString *)rightString withIsSelected:(BOOL)isSelected{
    _leftString = leftString;
    _rightString = [rightString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    _leftLabel.text = _leftString;
    
    _rightLabel.text = _rightString;

    
    
    _isSelected = isSelected;
    //_rightLabel.frame = CGRectMake(_leftLabel.right + 15,0 , self.frame.size.width - _leftLabel.width - 15, self.frame.size.height);
_rightLabel.textColor = MCColor(90, 90, 90, 1);
  
    if(_isSelected){
        
        _leftLabel.backgroundColor =  MCColor(0, 151, 255, 1);
        _leftLabel.textColor =[UIColor whiteColor];
        self.layer.borderColor =  MCColor(0, 151, 255, 1).CGColor;
    }else{
        
        _leftLabel.backgroundColor = MCColor(243, 243, 243, 1);
        _leftLabel.textColor = MCColor(0, 151, 255, 1);
        self.layer.borderColor =MCColor(243, 243, 243, 1).CGColor;
    }
}


//+(CGFloat)getViewHeight:(NSString * )rightlabelText{
//    
//    CGSize  labelSize = [MyUtils getLabelSize:rightlabelText withFont:26 withLabelWidth:WIDTH - 28 - 40];
//    return labelSize.height;
//}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
