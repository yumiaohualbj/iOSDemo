//
//  cellModel.m
//  masonry使用demo
//
//  Created by mac on 16/9/2.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "cellModel.h"

@implementation cellModel

@end
