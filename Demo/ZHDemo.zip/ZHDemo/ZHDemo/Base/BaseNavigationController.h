//
//  BaseNavigationController.h
//  WXMovie
//
//  Created by JayWon on 15/9/6.
//  Copyright (c) 2015年 JayWon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
