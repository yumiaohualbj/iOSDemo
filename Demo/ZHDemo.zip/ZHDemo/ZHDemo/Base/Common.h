//
//  Common.h
//  ZHDemo
//
//  Created by mac on 2017/2/16.
//  Copyright © 2017年 mac. All rights reserved.
//

#ifndef Common_h
#define Common_h

/*--屏幕的宽高----*/
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width
#define kScreenHeight    [UIScreen mainScreen].bounds.size.height

//tableview 分割线颜色
#define kTableViewSepColor [UIColor colorWithWhite:0.314 alpha:1.000]

#define kPhotoImageEdgeSize  40     //浏览相册照片的时候，给照片与照片之间加间隙
#endif /* Common_h */
