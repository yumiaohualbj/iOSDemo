//
//  BaseNavigationController.m
//  WXMovie
//
//  Created by JayWon on 15/9/6.
//  Copyright (c) 2015年 JayWon. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //设置背景
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"navigation"] forBarMetrics:UIBarMetricsDefault];
//    self.navigationBar setBackgroundImage:[UIImage createImageWithColor:[UIColor whiteColor]] forBarMetrics:UIBarMetricsDefault];
    self.navigationBar.shadowImage = nil;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,nil];
    // 4、设置导航栏半透明
    self.navigationController.navigationBar.translucent = NO;

    //设置标题文字的属性
    NSDictionary *titleDic = @{
                               NSFontAttributeName : [UIFont boldSystemFontOfSize:20],
                               NSForegroundColorAttributeName : [UIColor whiteColor]
                               };
    [self.navigationBar setTitleTextAttributes:titleDic];
    
    /*
    UIBarStyleDefault          = 0,
    UIBarStyleBlack            = 1, // 黑色
    UIBarStyleBlackOpaque      = 1, // 黑色不透明, Deprecated. Use UIBarStyleBlack
    UIBarStyleBlackTranslucent = 2, // 黑色半透明, Deprecated. Use UIBarStyleBlack and set the translucent property to YES
    */
    //设置 navigationBar 的样式，设置过后 navigationBar 失去了层次立体感
//    self.navigationBar.barStyle = UIBarStyleBlack;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

// 设置 UIStatusBar 的首选样式
- (UIStatusBarStyle)preferredStatusBarStyle {
    
    return UIStatusBarStyleLightContent;    //黑底白字
//    return UIStatusBarStyleDefault;         //白底黑字
}

@end
