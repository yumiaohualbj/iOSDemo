//
//  RootTabBarController.m
//  WXMovie
//
//  Created by JayWon on 15/9/6.
//  Copyright (c) 2015年 JayWon. All rights reserved.
//

#import "RootTabBarController.h"
#import "WXTabBarButton.h"
#import "Common.h"
#import "ZHHomeController.h"
#import "BaseNavigationController.h"
@interface RootTabBarController ()
{
    UIImageView *selectItem;
}

@end

@implementation RootTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //1、创建viewCtrls
    [self createViewCtrls];
    
    //2、自定义uitabbar
    [self customTabBar];
}

//如果RootTabBarController是通过storyboard加载的,那么移除的动作需要放在这个方法里面
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //移除系统tabbar自带的item
    [self removeUITabBarButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createViewCtrls
{
//    UIStoryboard *homeStbd = [UIStoryboard storyboardWithName:@"Home" bundle:nil];
//    UIStoryboard *newsStbd = [UIStoryboard storyboardWithName:@"News" bundle:nil];
//    UIStoryboard *topStbd = [UIStoryboard storyboardWithName:@"Top" bundle:nil];
//    UIStoryboard *cinemaStbd = [UIStoryboard storyboardWithName:@"Cinema" bundle:nil];
//    UIStoryboard *moreStbd = [UIStoryboard storyboardWithName:@"More" bundle:nil];
    
    ZHHomeController * homeCtrl = [[ZHHomeController alloc]init];
    
    BaseNavigationController * homeNav = [[BaseNavigationController alloc]initWithRootViewController:homeCtrl];

    
    NSArray * viewCtrls = @[homeNav];
    
//    NSArray *viewCtrls = @[
//                           [homeStbd instantiateInitialViewController],
//                           [newsStbd instantiateInitialViewController],
//                           [topStbd instantiateInitialViewController],
//                           [cinemaStbd instantiateInitialViewController],
//                           [moreStbd instantiateInitialViewController],
//                           ];
    
    self.viewControllers = viewCtrls;
}

-(void)customTabBar
{
    float itemWidth = kScreenWidth ;
    
    //背景
    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tab_bg_all"]];
    
    //选中的样式
    selectItem = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"selectTabbar_bg_all1"]];
    selectItem.frame = CGRectMake(0, 0, itemWidth, 48);
    [self.tabBar addSubview:selectItem];
    
    
    //tabbar按钮
    NSArray *titlesArr = @[@"首页"];
    NSArray *imgArr = @[
                        @"movie_home",
                        ];
    
    for (int i=0; i<1; i++) {
        NSString *title = titlesArr[i];
        NSString *imgName = imgArr[i];
        
        WXTabBarButton *item = [[WXTabBarButton alloc]
                                    initWithFrame:CGRectMake(i*itemWidth, 0, itemWidth, 49)
                                    withImgName:imgName
                                    withTitle:title];
        [item addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        item.tag = 1000 + i;
        [self.tabBar addSubview:item];
    }
    
}

-(void)buttonAction:(WXTabBarButton *)sender
{
    self.selectedIndex = sender.tag - 1000;
    
    [UIView animateWithDuration:.3 animations:^{
        selectItem.center = sender.center;
    }];
}

-(void)removeUITabBarButton
{
    for (UIView *view in self.tabBar.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [view removeFromSuperview];
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
