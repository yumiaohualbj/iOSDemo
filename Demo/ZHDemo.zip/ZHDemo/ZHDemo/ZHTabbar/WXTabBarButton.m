//
//  WXTabBarButton.m
//  WXMovie
//
//  Created by JayWon on 15/9/6.
//  Copyright (c) 2015年 JayWon. All rights reserved.
//

#import "WXTabBarButton.h"

#define kItemImgSize 20

@implementation WXTabBarButton

-(instancetype)initWithFrame:(CGRect)frame
                 withImgName:(NSString *)imgName
                   withTitle:(NSString *)title
{
    self = [super initWithFrame:frame];
    
    if (self != nil) {
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake((frame.size.width-kItemImgSize)/2, 5, kItemImgSize, kItemImgSize)];
        imgView.image = [UIImage imageNamed:imgName];
        imgView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:imgView];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(imgView.frame)+5, frame.size.width, 15)];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont systemFontOfSize:14];
        titleLabel.text = title;
        [self addSubview:titleLabel];
    }
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
